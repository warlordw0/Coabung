function scrHitboxRectangle(arg0, arg1, arg2, arg3)
{
    var check = false;
    var color = 255;
    if (point_in_rectangle(mouse_x, mouse_y, arg0, arg1, arg2, arg3))
    {
        check = true;
        color = 16711680;
        if (mouse_check_button(mb_left))
        {
            color = 32768;
        }
    }
    if (keyboard_check(ord("N")))
    {
        draw_set_color(color);
        draw_rectangle(arg0, arg1, arg2, arg3, true);
        draw_set_color(c_white);
    }
    return check;
}
