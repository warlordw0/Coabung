condom_jiggle_move += (((((-0.25 * grab) - condom_jiggle) * 0.75) - condom_jiggle_move) * 0.05);
condom_jiggle += condom_jiggle_move;
if (grab == true)
{
    x += ((mouse_x - x) * 0.15);
    y += (((mouse_y + (32 * (condom_size - condom_jiggle))) - y) * 0.15);
    if (mouse_check_button_released(mb_left))
    {
        grab = false;
    }
}
else
{
    y += ((496 - y) * 0.1);
}
