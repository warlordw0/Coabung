if (other.x > x)
{
    x -= 0.1;
}
if (other.x < x)
{
    x += 0.1;
}
