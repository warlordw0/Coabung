var wiggle = 0.05 * dcos(current_time / 64);
var breathe = 0;
var animation_speed = 0.1;
var starfield = false;
background_sprite = sBackgroundBedroom;
background_sprite_animated = -1;
ground_y = 480;
allow_condom_strip = true;
table_bounce_amount = 100;
switch (background_id)
{
    case 1:
        background_sprite = sBackgroundBeach;
        allow_condom_strip = false;
        break;
    case 2:
        background_sprite = sBackgroundOffice;
        wiggle = 0;
        ground_y = 500;
        table_bounce_amount = 0;
        break;
    case 3:
        background_sprite = sBackgroundStarship;
        starfield = true;
        ground_y = 500;
        table_bounce_amount = 0;
        break;
    case 4:
        background_sprite = sBackgroundVIPLounge;
        wiggle = 0;
        break;
    case 5:
        background_sprite = sBackgroundDungeon;
        background_sprite_animated = sBackgroundDungeonAnimated;
        allow_condom_strip = false;
        break;
}
if (oFutaMatingPress.custom_bedroom_selected != -1)
{
    background_sprite = oFutaMatingPress.custom_bedroom;
    if (oFutaMatingPress.custom_bedroom_animated != -1)
    {
        background_sprite_animated = oFutaMatingPress.custom_bedroom_animated;
        animation_speed = oFutaMatingPress.background_animation_speed;
    }
    wiggle = 0;
    allow_condom_strip = oFutaMatingPress.background_allow_condom_strip;
    if (oFutaMatingPress.background_breathe == true)
    {
        breathe = 0.03 * dcos(current_time / 25);
    }
}
draw_sprite_ext(background_sprite, 0, x, y, 2, 2, 0, c_white, 1);
if (starfield == true)
{
    for (var i = 0; i < 4; i++)
    {
        starfield_scale[i] += 0.0025;
        if (starfield_scale[i] > 1)
        {
            starfield_scale[i] = 0;
        }
        draw_sprite_ext(sBackgroundStarfield, 1, x, y, 1 + (starfield_scale[i] * 2), 1 + (starfield_scale[i] * 2), 90 * i, c_white, 2 * (0.5 - abs(0.5 - starfield_scale[i])));
    }
}
else if (background_sprite_animated != -1)
{
    draw_sprite_ext(background_sprite_animated, animated_background_frame, x, y, 2, 2, 0, c_white, 1);
    animated_background_frame += animation_speed;
}
else
{
    draw_sprite_ext(background_sprite, 1, x, y, 2, 2 + wiggle, 0, c_white, 1);
}
if (oFutaMatingPress.foreground_front == false)
{
    draw_sprite_ext(background_sprite, 2, x, (y + (50 * oFutaMatingPress.background_breathe * 0.03)) - (100 * breathe), 2, 2 + breathe, 0, c_white, 1);
}
draw_sprite_ext(background_sprite, 3, x, y + (body_jiggle * 84 * 2), (1 + body_jiggle) * 2, (1 - body_jiggle) * 2, 0, c_white, 1);
if (cum == true)
{
    draw_sprite_ext(sBackgroundCum, oFutaMatingPress.cum_outline, x, y + (body_jiggle * 84), (1 + body_jiggle) * 2, (1 - body_jiggle) * 2, 0, oFutaMatingPress.cum_color, 1);
}
