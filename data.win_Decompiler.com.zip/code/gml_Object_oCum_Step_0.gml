ground_y = oBackground.ground_y;
if (y < (ground_y + y_offset))
{
    x += hsp;
    y += vsp;
    vsp += grav;
    part_particles_create_color(global.ps, x, y, part_cum, oFutaMatingPress.cum_color, 1);
    image_xscale += ((size - image_xscale) * 0.1);
    image_yscale += ((size - image_yscale) * 0.1);
}
else
{
    y = ground_y + y_offset + 2;
    image_xscale = 2 * size;
    image_yscale = 0.5 * size;
}
