body_jiggle_move += ((((0 - body_jiggle) * 0.75) - body_jiggle_move) * 0.05);
body_jiggle += body_jiggle_move;
