body_jiggle = 0;
body_jiggle_move = 0;
cum = false;
ground_y = 468;
allow_condom_strip = false;
table_bounce_amount = 128;
background_sprite = sBackgroundBedroom;
background_sprite_animated = -1;
background_id = 0;
animated_background_frame = 0;
outline_surface = surface_create(room_width, room_height);
scrOutlineInit();
for (var i = 0; i < 4; i++)
{
    starfield_scale[i] = 0.25 * i;
}
x = room_width / 2;
y = room_height / 2;
