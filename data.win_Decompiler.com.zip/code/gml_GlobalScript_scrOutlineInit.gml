function scrOutlineInit()
{
    uni_size = shader_get_uniform(shdOutline, "size");
    uni_thick = shader_get_uniform(shdOutline, "thick");
    uni_color = shader_get_uniform(shdOutline, "oColor");
    uni_acc = shader_get_uniform(shdOutline, "accuracy");
    uni_tol = shader_get_uniform(shdOutline, "tol");
    uni_uvs = shader_get_uniform(shdOutline, "uvs");
}
