function scrSetPalette(arg0)
{
    if (shader_is_compiled(shdPaletteSwap))
    {
        var palette_swap_sampler = shader_get_sampler_index(shdPaletteSwap, "Palette");
        var texture_palette = sprite_get_texture(sPalettePicker, 0);
        var v_offset = shader_get_uniform(shdPaletteSwap, "Offset");
        shader_reset();
        shader_set(shdPaletteSwap);
        texture_set_stage(palette_swap_sampler, texture_palette);
        shader_set_uniform_f(v_offset, arg0 / 256);
    }
}
